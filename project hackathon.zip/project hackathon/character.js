/* Variables */
var canvas = document.getElementById('speelveld');
/* Settings */
var characterSizeX = 100
var characterSizeY = 300
var characterJumpHeight = 200
/* Functions */
const clamp = (n, min, max) => Math.min(Math.max(n, min), max)

class character {

    constructor(ctx) {
        this.x = canvas.clientWidth/2;
        this.jumpPower = 10;
        this.jump = false;
        this.vy = 0;
        this.gravity = 1.3;
        this.sizeY = characterSizeY
        this.currentJumpHeight = 0
        this.ctx = ctx
        this.y = canvas.height-this.sizeY;
    }

    draw() {
        const img = new Image()
        img.src = "./img/character.png"
        this.ctx.drawImage(img, this.x, this.y, characterSizeX, characterSizeY)
    }

    move() {
       if (this.jump){
            this.currentJumpHeight += this.jumpPower
            if (this.currentJumpHeight == characterJumpHeight){
                this.currentJumpHeight = 0
                this.vy = 0;
                this.jump = false
            }
            this.y -= this.jumpPower
       }
       if (!this.jump && this.y < 300){
            this.vy -= this.gravity
            this.y -= this.vy
            // this.y = clamp(this.y, characterSizeY, canvas.height-characterSizeY)
       }else if(this.y > 300){
            this.y = 300;
       }
    //   if(this.jump) {
    //     this.vy = 4;
    //     this.jump = false
    //   } else {
    //     clamp(this.vy, 0, 100)
    //     console.log(this.vy)
    //   }
    //   if (this.y == canvas.height-characterSize){
    //     this.y -= this.vy
    //     this.vy -= this.gravity
    //   }
    }

}