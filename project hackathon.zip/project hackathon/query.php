<?php require("mail.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="character.js" defer></script>
    <script src="main.js" defer></script>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <p id="vraag">DIT IS EEN TEST</p>
    <article id="questionBoxes">

    </article>
    <canvas id="speelveld"></canvas>
</body>
</html>