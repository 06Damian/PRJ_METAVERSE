<?php
session_start();
if(isset($_POST['submit'])){
    if(empty($_POST['email']) || empty($_POST['Voornaam']) || empty($_POST['Achternaam'])){
        $response = "All the field are required";
    }else{
        $response = "succes";
        ?> <meta http-equiv="refresh" content="3; URL=http://localhost/project%20hackathon/query.php"/>  <?php
    }
}
?>
<form action="" method="post" enctype="multipart/form-data">
    <label>Uw email</label>
    <input type="email" name="email" value="">

    <label>Voornaam</label>
    <input type="name" name="Voornaam" value="">

    <label>Tussenvoegsel</label>
    <input type="text" name="Tussenvoegsel" value=""> 

    <label>Achternaam</label>
    <input type="text" name="Achternaam" value="">

    <button type="submit"name="submit">Begin</button>
</form>
<?php
$_SESSION[$_POST['email']];
$_SESSION[$_POST['Voornaam']];
$_SESSION[$_POST['Tussenvoegsel']];
$_SESSION[$_POST['Achternaam']];
?>