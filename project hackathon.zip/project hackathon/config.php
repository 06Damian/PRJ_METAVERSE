<?php 
//define the smtp mailserver host
define('MAILHOST', "smtp.gmail.com");

//Define the username/gmail that u are using
define('USERNAME', "tmpschl@gmail.com");

//Define here the passkey you got from gmail doing all that stuff
define('PASSWORD', "aksc puxc fras nhpo");

//Define the send from mail the tutorial said a different one but i hope it will be fine
define('SEND_FROM', "tmpschl@gmail.com");

//Define the Send from name
define('SEND_FROM_NAME', "Romp_Quick_Test");

//the mail here has to become a variable to ensure we use the users mail
define('REPLY_TO', "tmpschl@gmail.com");

//The reply name
define('REPLY_TO_NAME', "George");

?>