var canvas = document.getElementById('speelveld');
var questionBoxFrame = document.getElementById('questionBoxes')
var question = document.getElementById('vraag')
var ctx = canvas.getContext('2d');

var squareWidth = 10
var sqaureHeight = 10

var player_speed = 10
var enemie_speed = 2.5

var itemWidth = 10
var itemHeight = 10

var enemieX = canvas.width/2
var enemieY = canvas.height/2

var items = []
var enemies = []

var currentVraag = 'vraag1'

var vragenAntwoord = {
    vraag1: {
        vraag: "Mijn organisatie is?",
        antwoorden: [
            ["Klein < 250", "vraag2"],
            ["Medium 250-500", "vraag2"],
            ["Groot 1000 >", "vraag2"]
        ]
    },
    vraag2: {
        vraag: "De IT dienstverlening binnen mijn organisatie is?",
        antwoorden: [
            ["Is uit zijn jasje gegroeid", "vraag3"],
            ["Kan naar een hoger niveau", "vraag4"],
            ["Heeft te maken met (nieuwe) wet en regelgeving", "vraag5"],
            ["Is goed zoals het is", "vraag6"]
        ]
    },
    vraag3: {
        vraag: "Dit komt door",
        antwoorden: [
            ["Organische groei", "Resultaat1"],
            ["Fusie", "Resultaat2"]
        ],
        resultaat: {
            Resultaat1: "Door gebruik te maken van use cases en het leggen van verbindingen tussen verschillende afdelingen op basis van werkelijke gebeurtenissen, kan RTOM de samenwerking en communicatie tussen teams verbeteren. Het helpt bij het begrijpen van onderlinge afhankelijkheden en bevordert een holistische benadering van operaties.",
            Resultaat2: "RTOM is ontworpen voor de volledige transformatie van het IT-landschap. Het biedt een gestructureerde aanpak om organisatorische transformatie te faciliteren, inclusief veranderingen in het Target Operating Model en de aanbesteding van kavels."
        }
    },
    vraag4: {
        vraag: "Wij willen graag",
        antwoorden: [
            ["Vergroten van wendbaarheid en beter inspelen op innovatie en technische verandering", "Resultaat3"],
            ["(Her) structureren van bedrijfsprocesn", "Resultaat4"],
            ["Met IT dienstverlening beter inspelen op klantvraag", "Resultaat5"]
        ],
        resultaat: {
            Resultaat3: "Door te werken met use cases en een agnostische benadering te hanteren, kan RTOM organisaties helpen om wendbaarder en aanpasbaarder te zijn. Het stelt hen in staat om snel te reageren op veranderingen in de bedrijfsomgeving en nieuwe technologische ontwikkelingen.",
            Resultaat4: "RTOM streeft naar de integratie van diverse best practices en benaderingen binnen de organisatie. Het maakt het mogelijk om waardevolle elementen van verschillende frameworks te combineren en te harmoniseren, waardoor een samenhangend geheel ontstaat.",
            Resultaat5: "Door te werken met use cases en een agnostische benadering te hanteren, kan RTOM organisaties helpen om wendbaarder en aanpasbaarder te zijn. Het stelt hen in staat om snel te reageren op veranderingen in de bedrijfsomgeving en nieuwe technologische ontwikkelingen."
        }
    },
    vraag5: {
        vraag: "En willen dit",
        antwoorden: [
            ["inrichten", "Resultaat6"],
            ["automatiseren", "Resultaat7"]
        ],
        resultaat: {
            Resultaat6: "Door de focus op de volledige levenscyclus van IT-processen en het gebruik van best practices en frameworks als Cobit en ISO 27001  kan RTOM organisaties helpen bij het optimaliseren van hun IT-processen. Dit kan leidt tot verbeterde efficiëntie, aantoonbaar in control  en een hogere kwaliteit van IT-diensten ",
            Resultaat7: "Om optimale samenwerking en communicatie tussen partijen  te faciliteren maakt het RTOM gebruik van standaarden t.a.v. informatie-uitwisseling en proces-integraties inzichtelijk en de vertaling  naar API’s"
        }
    },
    vraag6: {
        vraag: "Want: (vink aan wat van toepassing)",
        antwoorden: [
            ["Alle koppelvlakken met serviceproviders zijn geautomatiseerd ", "Resultaat8", "Resultaat9"],
            ["Optimale samenwerking met service providers en vendoren", "Resultaat8", "Resultaat9"],
            ["Er wordt snel en adequaat ingespeeld op de klantvraag", "Resultaat8", "Resultaat9"]
        ],
        resultaat: {
            Resultaat8: "Alles aangevinkt: Gefeliciteerd!! Uw organisatie is fantastisch en  een voorbeeld voor ons allen! ",
            Resultaat9: "Niet alles aangevinkt: (bijv) RTOM is ook geschikt om alle koppelvlakken met serviceproviders te automatiseren"
        }
    }
};

var savedAnswers = []
 
// let vraag = vragenAntwoord[3].vraag;
// let answer = vragenAntwoord[3].antwoorden[43][0];
// let resultaat = vragenAntwoord[3].resultaat["Resultaat5"];

function getAnswers(vraag){
    let vraagArray = vragenAntwoord[vraag]
    if (vraagArray){
        question.innerHTML = ""
        question.innerHTML = vraagArray['vraag']
        question.style.opacity = 1
        question.style.fontSize = '5vh'
        return vraagArray['antwoorden']
    }
}

function isColliding(playerX, playerY, objectX, objectY, objectWidth, objectHeight){
    return !(playerX + squareWidth < objectX ||
             playerX > objectX + objectWidth ||
             playerY + sqaureHeight < objectY ||
             playerY > objectY + objectHeight);
}

function displayAnswer(answer){
    questionBoxFrame.style.gridTemplateColumns = "1fr"
    const paragraph = document.createElement("p")
    paragraph.innerText = answer
    paragraph.style.color = 'white'
    paragraph.style.fontSize = '3.5vh'
    paragraph.style.margin = '10px'
    paragraph.style.transition = '500ms' 
    paragraph.style.opacity = 0
    paragraph.style.borderRadius = '5px'
    paragraph.style.color = 'black'
    paragraph.style.backgroundColor = 'white'

    let orginalWidth = paragraph.width
    questionBoxFrame.appendChild(paragraph)
    paragraph.width = orginalWidth
    paragraph.style.opacity = 1
}

function createQuestionBoxes(array){
    questionBoxFrame.style.gridTemplateColumns = "repeat(" + array.length + ", 1fr)"
    array.forEach(answerBox => {
        const section = document.createElement("section")
        const paragraph = document.createElement("p")
        paragraph.innerText = answerBox[0]
        section.appendChild(paragraph)
        section.style.opacity = 0
        section.id = answerBox[1]
        questionBoxFrame.appendChild(section)
    })
}

function setupQuestions(characterClass){
    var debounce = false
    var canvasRect = canvas.getBoundingClientRect()
    var questionBox = document.getElementById('questionBoxes').querySelectorAll('section')
    questionBox.forEach(paragraph => {
        paragraph.style.transition = '500ms'
        paragraph.style.opacity = 1
        setInterval(() => {
            var articleRect = paragraph.getBoundingClientRect()
            var relativeTop = articleRect.top-canvasRect.top
            var relativeLeft = articleRect.left-canvasRect.left
            var width = paragraph.clientWidth
            var height = paragraph.clientHeight
            if (isColliding(characterClass.x, characterClass.y, relativeLeft, relativeTop, width, height) && !debounce){
                question.style.opacity = 0
                question.style.fontSize = '0vh'
                var oldMargin = paragraph.style.marginBottom
                paragraph.style.marginBottom = '10px'
                paragraph.style.backgroundColor = 'darkgrey'
                debounce = true
                var backInterval = setInterval(() => {
                    let previousVraag = currentVraag
                    let nextId = paragraph.id
                    currentVraag = nextId
                    paragraph.style.marginBottom = oldMargin
                    clearInterval(backInterval)
                    /* Fire answer thing */
                    var fadeOutInterval = setInterval(() => {
                        clearInterval(fadeOutInterval)
                        questionBox.forEach(paragraph => {
                            paragraph.style.opacity = 0
                        })
                        var clearFramesInterval = setInterval(() => {
                            clearInterval(clearFramesInterval)
                            questionBoxFrame.innerHTML = ''
                            let answers = getAnswers(currentVraag)
                            savedAnswers.push(previousVraag)
                            if (answers){
                                createQuestionBoxes(answers)
                                setupQuestions(characterClass)
                            }else{
                                var result = vragenAntwoord[previousVraag].resultaat[currentVraag]
                                displayAnswer(result)
                                savedAnswers.push(result)
                            }
                        }, 500);
                    }, 500);
                }, 500 /* Transition time */);
                // var debounceInterval = setInterval(() => {
                //     if (!isColliding(characterClass.x, characterClass.y, relativeLeft, relativeTop, width, height)){
                //         clearInterval(debounceInterval)
                //     }
                // }, 100);
            }
        }, 5);
    })
}

ctx.scale(2,2)

window.onload = function(){
    const img = new Image()
    img.src = "./img/bg.png"
    img.onload = () => {
        ctx.imageSmoothingEnabled = false;
        ctx.webkitImageSmoothingEnabled = false;
        ctx.mozImageSmoothingEnabled = false;
        ctx.msImageSmoothingEnabled = false;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
    }
    var functions = []
    canvas.width = 1500;
    canvas.height = 600;
    const characterClass = new character(ctx)
    setInterval(function(){ characterClass.move() }, 30)
    characterClass.draw()
    /* Draw function */
    functions.push(function(){
        ctx.imageSmoothingEnabled = false;
        ctx.webkitImageSmoothingEnabled = false;
        ctx.mozImageSmoothingEnabled = false;
        ctx.msImageSmoothingEnabled = false;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
        characterClass.draw()
    });
    /* Player movement */
    var left = false
    var right = false
    window.addEventListener('keydown', function(e){
        if(e.keyCode == 65){left=true}
        if(e.keyCode == 68){right=true}
    })
    window.addEventListener('keyup', function(e){
        if(e.keyCode == 65){left=false}
        if(e.keyCode == 68){right=false}
    })
    window.addEventListener('keypress', function(e){ 
        if(e.keyCode == 32 && canvas.height-characterClass.sizeY <= characterClass.y)
            characterClass.jump = true; 
            e.preventDefault();
        })
    functions.push(function(){
        if(left){
            characterClass.x -= player_speed
            characterClass.x = clamp(characterClass.x, 0, canvas.width)
        }
        if(right){
            characterClass.x += player_speed
            characterClass.x = clamp(characterClass.x, 0, canvas.width)
        }
        clamp(characterClass.x, 0, canvas.width)
    })
    let answers = getAnswers(currentVraag)
    console.log(answers)
    createQuestionBoxes(answers)
    /* Function loop */
    functions.forEach(function(func){
        setInterval(func, 30)
    })
    setupQuestions(characterClass)
}

    fetch('mail.php', { //Aangeven naar welk bestand
    method: 'POST', //Soort versturing, POST net zoals forms
    headers: {
        'Content-Type': 'application/json' //Soort data die verstuurd word
    },
    body: JSON.stringify(savedAnswers) //De data zelf omzetten in text
    })
    .then(response => response.text()) //Text versturen
    .then(data => {
    console.log(data); // Log de respons van het PHP-bestand
    // Voeg hier eventueel andere acties toe na ontvangst van de respons
    })
