<?php     session_start();
require("script.php"); 
?>

<?php
    $antwoordvraag1D = ""; 
    $antwoordvraag2D = "";
    $antwoordvraag3D = "";
    $resultaat = "";
    $response = "";
    $tussen = "";
?>
<?php 
    $data = json_decode(file_get_contents("php://input")); //Vang de data op die door fetch API verstuurd word en zet het om in een object
    print_r($data);
    function emailSentD($antwoordvraag1, $antwoordvraag2, $antwoordvraag3, $resultaat, $tussen){
        $standerdsubject = "Resultaten ROMP quick test";
        $messagemade = "Beste meneer/mevrouw ".$tussen. $SESSION[$_POST['Achternaam']] .",\nWe hebben de resultaten van uw test.\nUw antwoord op vraag 1 was: ". $antwoordvraag1."\nUw antwoord op vraag 2 was: ". $antwoordvraag2."\nUw antwoord op vraag 3 was: ". $antwoordvraag3."\nHier uit hebben we een resultaat kunnen maken namelijk:". $resultaat ."\n Dankuwel voor uw tijd en als u meer infromatie wil of wil dat wij u verder helpen twijfel dan niet en neem contact op.\n\nMet vriendelijke groet,\nHet team van ROMP";
        sendMail($SESSION[$_POST['email']], $standerdsubject, $messagemade);
    };
    
    if(empty($SESSION[$_POST['Tussenvoegsel']])){
        $tussen = "";
    }else{
        $tussen = $SESSION[$_POST['Tussenvoegsel']]." ";
    };
    if(!empty($data)){
        emailSentD($data[0], $data[1], $data[2], $data[3], $tussen);
    };
    

?>