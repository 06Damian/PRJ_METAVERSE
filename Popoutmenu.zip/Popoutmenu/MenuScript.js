const Notif = document.getElementById('Notification');
const menuButton = document.getElementById('menu-button');
const popoutMenu = document.getElementById('popout-menu');
const popoutEmbed = document.getElementById('popout-embed');

let menuVisible = false;
console.log(menuVisible)
Notif.style.display = "flex";
    

setTimeout(() => {
    Notif.style.opacity = "100%";
}, 50);
setTimeout(() => {
    Notif.style.opacity = "0%";
}, 4000);
setTimeout(() => {
    Notif.style.display = "none";
}, 4500);

menuButton.addEventListener('click', function(){
    console.log(menuVisible)

        if (menuVisible == true) {
            
            popoutMenu.style.height = '0px';
            popoutMenu.style.width = '0px';
            popoutEmbed.style.height = '0px';
            popoutEmbed.style.width = '0px';
            setTimeout(() => {
                popoutMenu.style.display = "none";
            }, 600);
            
            menuVisible = false;
        } else if (menuVisible == false) {
            popoutMenu.style.display = "block";
            setTimeout(() => {
                popoutMenu.style.height = "300px";
                popoutMenu.style.width = "600px";
                popoutEmbed.style.height = '300px';
                popoutEmbed.style.width = '600px';
            }, 5);
            menuVisible = true;
        }
});